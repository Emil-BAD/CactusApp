from django.apps import AppConfig


class CactusappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'CactusApp'
